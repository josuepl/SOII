import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Saludo extends Remote {
    String decirHola(String nombre) throws RemoteException;
}