import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Cliente {
    public static void main(String[] args) {
        try {
            // Obtener el registro RMI del servidor (localhost:1099)
            Registry registro = LocateRegistry.getRegistry("localhost", 1099);
            
            // Buscar el servicio remoto por nombre
            Saludo servicio = (Saludo) registro.lookup("SaludoServicio");
            
            // Invocar método remoto
            String respuesta = servicio.decirHola("Pepe");
            System.out.println("Respuesta del servidor: " + respuesta);
        } catch (Exception e) {
            System.err.println("Error en cliente: " + e.getMessage());
        }
    }
}