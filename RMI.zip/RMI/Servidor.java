import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Servidor {
    public static void main(String[] args) {
        try {
            // Crear instancia del servicio
            ServidorSaludo servicio = new ServidorSaludo();
            
            // Crear registro RMI en el puerto 1099
            Registry registro = LocateRegistry.createRegistry(1099);
            
            // Registrar el servicio con un nombre
            registro.rebind("SaludoServicio", servicio);
            
            System.out.println("Servidor RMI listo...");
        } catch (Exception e) {
            System.err.println("Error en servidor: " + e.getMessage());
        }
    }
}