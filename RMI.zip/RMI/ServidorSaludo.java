import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class ServidorSaludo extends UnicastRemoteObject implements Saludo {
    
    public ServidorSaludo() throws RemoteException {
        super(); // Llama al constructor de UnicastRemoteObject
    }

    @Override
    public String decirHola(String nombre) throws RemoteException {
        return "¡Hola, " + nombre + "! desde el servidor RMI.";
    }
}