#include <windows.h>
#include <stdio.h>
#include "suma.h"  // Generado por MIDL

int main() {
    RPC_STATUS status;
    RPC_WSTR pszBinding = NULL;
    int resultado = 0;

    // Crear binding handle
    status = RpcStringBindingCompose(
        NULL,  // UUID (usamos binding implícito)
        (RPC_WSTR)L"ncacn_ip_tcp",  // Protocolo
        (RPC_WSTR)L"localhost",     // Servidor
        (RPC_WSTR)L"4747",         // Puerto
        NULL, &pszBinding);
    if (status != RPC_S_OK) {
        printf("Error al componer binding: 0x%x\n", status);
        return 1;
    }

    // Conectar al servidor
    status = RpcBindingFromStringBinding(pszBinding, &hSumaBinding);
    if (status != RPC_S_OK) {
        printf("Error al crear binding handle: 0x%x\n", status);
        return 1;
    }

    // Llamar a la función remota
    printf("Cliente: Llamando a Sumar(5, 3)...\n");
    resultado = Sumar(5, 3);
    printf("Resultado: %d\n", resultado);

    // Liberar recursos
    RpcStringFree(&pszBinding);
    RpcBindingFree(&hSumaBinding);

    return 0;
}

// Funciones de gestión de memoria (igual que en el servidor)
void* __RPC_USER MIDL_user_allocate(size_t size) {
    return malloc(size);
}

void __RPC_USER MIDL_user_free(void* p) {
    free(p);
}