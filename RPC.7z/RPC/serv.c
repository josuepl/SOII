#include <windows.h>
#include <stdio.h>
#include "suma.h"  // Generado por MIDL

// Implementación de la función remota
int Sumar(int a, int b) {
    return a + b;
}

int main() {
    RPC_STATUS status;
    RPC_WSTR pszProtocolSequence = (RPC_WSTR)L"ncacn_ip_tcp";  // Usar TCP/IP
    RPC_WSTR pszEndpoint = (RPC_WSTR)L"4747";  // Puerto 4747

    // Registrar la interfaz
    status = RpcServerUseProtseqEp(pszProtocolSequence, RPC_C_PROTSEQ_MAX_REQS_DEFAULT, pszEndpoint, NULL);
    if (status != RPC_S_OK) {
        printf("Error al registrar protocolo: 0x%x\n", status);
        return 1;
    }

    // Registrar la interfaz SumaInterface
    status = RpcServerRegisterIf2(
        SumaInterface_v1_0_s_ifspec,  // Interfaz generada por MIDL
        NULL, NULL, 0, RPC_C_LISTEN_MAX_CALLS_DEFAULT, 0, NULL);
    if (status != RPC_S_OK) {
        printf("Error al registrar interfaz: 0x%x\n", status);
        return 1;
    }

    printf("Servidor RPC escuchando en puerto 4747...\n");
    status = RpcServerListen(1, RPC_C_LISTEN_MAX_CALLS_DEFAULT, FALSE);
    if (status != RPC_S_OK) {
        printf("Error al iniciar escucha: 0x%x\n", status);
        return 1;
    }

    return 0;
}

// Función requerida por RPC para gestionar memoria
void* __RPC_USER MIDL_user_allocate(size_t size) {
    return malloc(size);
}

void __RPC_USER MIDL_user_free(void* p) {
    free(p);
}